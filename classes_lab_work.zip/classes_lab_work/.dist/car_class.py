from class_vehicle import class_vehicle
class Vehicle:
    def __init__(self, color):
        self.color = color

    def get_color(self):
        return self.color

    def __str__(self):
        return f"This vehicle is {self.color}"


# Car class that extends vehicle
class Car(Vehicle):
    def __init__(self, color, has_winter_tires=False):
        super().__init__(color)
        self.has_winter_tires = has_winter_tires

    def __str__(self):
        vehicle_desc = super().__str__()
        return f"{vehicle_desc}\nHas winter tires: {self.has_winter_tires}"


