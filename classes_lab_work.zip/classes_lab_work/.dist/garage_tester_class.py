from truck_class import truck_class
from garage_class import garage_class

class GarageTester:
    @staticmethod
    def get_example():
        truck = Truck("black", False)
        garage = Garage()
        garage.set_vehicle(truck)
        return garage


