from class_vehicle import class_vehicle

class Vehicle:
    def __init__(self, color):
        self.color = color

    def get_color(self):
        return self.color

    def __str__(self):
        return f"This vehicle is {self.color}"


# Truck class that extends vehicle
class Truck(Vehicle):
    def __init__(self, color, has_trailer=False):
        super().__init__(color)
        self.has_trailer = has_trailer

    def __str__(self):
        vehicle_desc = super().__str__()
        return f"{vehicle_desc}\nHas trailer: {self.has_trailer}"


